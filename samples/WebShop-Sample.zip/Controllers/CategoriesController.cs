using Microsoft.AspNetCore.Mvc;
using Regira.Entities.Web.Abstractions;
using WebShop.Models.DTOs;
using WebShop.Models.Entities;
using WebShop.Models.SearchObjects;

namespace WebShop.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CategoriesController : EntityControllerBase<Category, CategorySearchObject, CategoryDto, CategoryInputDto>
{
    // All CRUD endpoints are inherited from base controller
}
