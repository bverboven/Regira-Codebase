using Microsoft.AspNetCore.Mvc;
using Regira.Entities.Web.Abstractions;
using WebShop.Models.DTOs;
using WebShop.Models.Entities;
using WebShop.Models.Enums;
using WebShop.Models.SearchObjects;

namespace WebShop.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : EntityControllerBase<Product, ProductSearchObject, ProductSortBy, ProductIncludes, ProductDto, ProductInputDto>
{
    // All CRUD endpoints are inherited from base controller:
    // - GET /api/products
    // - GET /api/products/{id}
    // - POST /api/products/search
    // - POST /api/products
    // - PUT /api/products/{id}
    // - DELETE /api/products/{id}
    
    // Custom endpoint example
    [HttpGet("low-stock")]
    public async Task<IActionResult> GetLowStock([FromQuery] int threshold = 10)
    {
        var searchObject = new ProductSearchObject
        {
            MinStock = 0,
            MaxPrice = threshold,
            IsArchived = false
        };
        
        var result = await Search(searchObject, null);
        return Ok(result);
    }
}
