using Microsoft.AspNetCore.Mvc;
using Regira.Entities.Web.Attachments.Abstractions;
using WebShop.Models.Entities;

namespace WebShop.Controllers;

[ApiController]
[Route("api/products/{objectId}/attachments")]
public class ProductAttachmentsController : EntityAttachmentControllerBase<ProductAttachment, int, int>
{
    // Endpoints:
    // - GET /api/products/{objectId}/attachments
    // - GET /api/products/{objectId}/attachments/{id}
    // - POST /api/products/{objectId}/attachments (multipart/form-data)
    // - PUT /api/products/{objectId}/attachments/{id}
    // - DELETE /api/products/{objectId}/attachments/{id}
}
