using System.ComponentModel.DataAnnotations;
using Regira.Entities.Abstractions;
using Regira.Entities.Models.Attributes;

namespace WebShop.Models.Entities;

public class Category : IEntity<int>, IHasTimestamps, IHasTitle, IHasDescription
{
    public int Id { get; set; }
    
    [Required, MaxLength(100)]
    public string Title { get; set; } = null!;
    
    [MaxLength(500)]
    public string? Description { get; set; }
    
    // Normalization
    [Normalized(SourceProperties = [nameof(Title), nameof(Description)])]
    public string? NormalizedContent { get; set; }
    
    // Timestamps
    public DateTime Created { get; set; }
    public DateTime? LastModified { get; set; }
    
    // Navigation
    public ICollection<Product>? Products { get; set; }
}
