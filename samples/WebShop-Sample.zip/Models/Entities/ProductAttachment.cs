using Regira.Entities.Attachments.Models;

namespace WebShop.Models.Entities;

public class ProductAttachment : EntityAttachment<int, int>
{
    public override string ObjectType => nameof(Product);
}
