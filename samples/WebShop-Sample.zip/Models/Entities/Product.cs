using System.ComponentModel.DataAnnotations;
using Regira.Entities.Abstractions;
using Regira.Entities.Models.Attributes;
using Regira.Entities.Attachments.Abstractions;

namespace WebShop.Models.Entities;

public class Product : IEntity<int>, IHasTimestamps, IArchivable, IHasTitle, IHasDescription,
    IHasAttachments, IHasAttachments<ProductAttachment>
{
    public int Id { get; set; }
    
    [Required, MaxLength(200)]
    public string Title { get; set; } = null!;
    
    [MaxLength(1000)]
    public string? Description { get; set; }
    
    public decimal Price { get; set; }
    
    public int Stock { get; set; }
    
    public int CategoryId { get; set; }
    
    // Normalization
    [Normalized(SourceProperties = [nameof(Title), nameof(Description)])]
    public string? NormalizedContent { get; set; }
    
    // Timestamps (IHasTimestamps)
    public DateTime Created { get; set; }
    public DateTime? LastModified { get; set; }
    
    // Soft delete (IArchivable)
    public bool IsArchived { get; set; }
    
    // Attachments (IHasAttachments)
    public bool? HasAttachment { get; set; }
    public ICollection<ProductAttachment>? Attachments { get; set; }
    ICollection<IEntityAttachment>? IHasAttachments.Attachments
    {
        get => Attachments?.Cast<IEntityAttachment>().ToArray();
        set => Attachments = value?.Cast<ProductAttachment>().ToArray();
    }
    
    // Navigation properties
    public Category? Category { get; set; }
}
