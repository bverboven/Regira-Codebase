using Regira.Entities.Models;

namespace WebShop.Models.SearchObjects;

public class CategorySearchObject : SearchObject
{
    // Uses default SearchObject properties (Q, IsArchived, Created, etc.)
}
