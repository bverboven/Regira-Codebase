using Regira.Entities.Models;

namespace WebShop.Models.SearchObjects;

public class ProductSearchObject : SearchObject
{
    // Category filtering
    public int? CategoryId { get; set; }
    public ICollection<int>? CategoryIds { get; set; }
    
    // Price filtering
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    
    // Stock filtering
    public int? MinStock { get; set; }
    public bool? InStock { get; set; }
}
