namespace WebShop.Models.Enums;

[Flags]
public enum ProductIncludes
{
    Default = 0,
    Category = 1 << 0,
    Attachments = 1 << 1,
    All = Category | Attachments
}
