namespace WebShop.Models.Enums;

public enum ProductSortBy
{
    Default = 0,
    Title = 1 << 0,
    TitleDesc = 1 << 1,
    Price = 1 << 2,
    PriceDesc = 1 << 3,
    Stock = 1 << 4,
    StockDesc = 1 << 5,
    Created = 1 << 6,
    CreatedDesc = 1 << 7,
    Category = 1 << 8
}
