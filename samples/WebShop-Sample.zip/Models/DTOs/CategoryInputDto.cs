using System.ComponentModel.DataAnnotations;

namespace WebShop.Models.DTOs;

public class CategoryInputDto
{
    [Required, MaxLength(100)]
    public string Title { get; set; } = null!;
    
    [MaxLength(500)]
    public string? Description { get; set; }
}
