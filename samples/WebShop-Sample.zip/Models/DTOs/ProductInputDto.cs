using System.ComponentModel.DataAnnotations;

namespace WebShop.Models.DTOs;

public class ProductInputDto
{
    [Required, MaxLength(200)]
    public string Title { get; set; } = null!;
    
    [MaxLength(1000)]
    public string? Description { get; set; }
    
    [Range(0.01, 999999.99)]
    public decimal Price { get; set; }
    
    [Range(0, 999999)]
    public int Stock { get; set; }
    
    [Required]
    public int CategoryId { get; set; }
}
