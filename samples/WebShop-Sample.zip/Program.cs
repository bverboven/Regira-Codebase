using Microsoft.EntityFrameworkCore;
using Regira.Entities.DependencyInjection;
using Regira.Entities.EFcore.Extensions;
using Regira.IO.Storage.Abstractions;
using Regira.IO.Storage;
using WebShop.Data;
using WebShop.Models.Entities;
using WebShop.Models.DTOs;
using WebShop.Models.SearchObjects;
using WebShop.Models.Enums;
using WebShop.Services.QueryBuilders;
using WebShop.Services.Normalizers;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configure Database
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<ShopDbContext>((serviceProvider, options) =>
{
    options.UseSqlServer(connectionString)
        .AddNormalizerInterceptors(serviceProvider)  // Auto-normalize on save
        .AddAutoTruncateInterceptors();               // Auto-truncate strings
});

// Configure File Storage for Attachments
builder.Services.AddSingleton<IFileService>(sp =>
{
    var uploadsPath = Path.Combine(builder.Environment.ContentRootPath, "uploads");
    return new BinaryFileService(uploadsPath);
});

// Configure Entities Framework
builder.Services
    .UseEntities<ShopDbContext>(options =>
    {
        // Add default normalizer (handles [Normalized] attributes)
        options.AddDefaultEntityNormalizer();
        
        // Use Mapster for object mapping
        options.UseMapsterMapping();
    })
    // Configure Product Entity
    .For<Product>(e =>
    {
        e.UseService<ProductQueryBuilder, ProductSearchObject, ProductSortBy, ProductIncludes>()
            .Sort<ProductSortedQueryBuilder>()
            .Include<ProductIncludesQueryBuilder>()
            .UseMapping<ProductDto, ProductInputDto>()
            .After((product, dto) =>
            {
                // Custom mapping logic
                dto.CategoryTitle = product.Category?.Title;
                dto.InStock = product.Stock > 0;
                dto.HasAttachments = product.HasAttachment == true;
                dto.AttachmentCount = product.Attachments?.Count ?? 0;
            });
        
        // Add custom normalizer
        e.AddNormalizer<ProductNormalizer>();
        
        // Configure attachments
        e.Attachments<ProductAttachment>(a =>
        {
            a.UseFileService<BinaryFileService>()
                .RootFolder("products");
        });
    })
    // Configure Category Entity
    .For<Category>(e =>
    {
        e.UseService()
            .Filter((query, so) =>
            {
                // Inline filter logic
                if (!string.IsNullOrWhiteSpace(so?.Q))
                {
                    var searchTerm = $"%{so.Q}%";
                    query = query.Where(x => 
                        EF.Functions.Like(x.Title, searchTerm) ||
                        EF.Functions.Like(x.Description ?? string.Empty, searchTerm));
                }
                return query;
            })
            .UseMapping<CategoryDto, CategoryInputDto>()
            .After((category, dto) =>
            {
                // Calculate product counts
                dto.ProductCount = category.Products?.Count ?? 0;
                dto.ActiveProductCount = category.Products?.Count(p => !p.IsArchived) ?? 0;
            });
    });

var app = builder.Build();

// Seed data
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ShopDbContext>();
    await SeedData.Initialize(context);
}

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();
