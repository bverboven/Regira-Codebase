using WebShop.Models.Entities;

namespace WebShop.Data;

public static class SeedData
{
    public static async Task Initialize(ShopDbContext context)
    {
        // Ensure database is created
        await context.Database.EnsureCreatedAsync();

        // Check if already seeded
        if (context.Categories.Any())
        {
            return;
        }

        // Seed categories
        var categories = new[]
        {
            new Category { Title = "Electronics", Description = "Electronic devices and accessories" },
            new Category { Title = "Computers", Description = "Laptops, desktops, and accessories" },
            new Category { Title = "Gaming", Description = "Gaming consoles and accessories" }
        };
        
        context.Categories.AddRange(categories);
        await context.SaveChangesAsync();

        // Seed products
        var products = new[]
        {
            new Product
            {
                Title = "Laptop Pro 15",
                Description = "High-performance laptop with 16GB RAM",
                Price = 1299.99m,
                Stock = 50,
                CategoryId = categories[1].Id
            },
            new Product
            {
                Title = "Gaming Mouse",
                Description = "RGB gaming mouse with 16000 DPI",
                Price = 79.99m,
                Stock = 100,
                CategoryId = categories[2].Id
            },
            new Product
            {
                Title = "Wireless Keyboard",
                Description = "Mechanical keyboard with RGB backlighting",
                Price = 129.99m,
                Stock = 75,
                CategoryId = categories[1].Id
            }
        };
        
        context.Products.AddRange(products);
        await context.SaveChangesAsync();
    }
}
