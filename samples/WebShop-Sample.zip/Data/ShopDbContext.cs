using Microsoft.EntityFrameworkCore;
using Regira.Entities.Attachments.Models;
using Regira.Entities.EFcore.Extensions;
using WebShop.Models.Entities;

namespace WebShop.Data;

public class ShopDbContext : DbContext
{
    public ShopDbContext(DbContextOptions<ShopDbContext> options) : base(options)
    {
    }

    public DbSet<Product> Products => Set<Product>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Attachment> Attachments => Set<Attachment>();
    public DbSet<ProductAttachment> ProductAttachments => Set<ProductAttachment>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Set decimal precision for all decimal properties
        modelBuilder.SetDecimalPrecisionConvention(18, 2);

        // Product configuration
        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasOne(e => e.Category)
                .WithMany(c => c.Products)
                .HasForeignKey(e => e.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);
            
            entity.HasIndex(e => e.Title);
            entity.HasIndex(e => e.CategoryId);
            entity.HasIndex(e => e.Price);
            entity.HasIndex(e => e.IsArchived);
            entity.HasIndex(e => e.Created);
        });

        // Category configuration
        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasIndex(e => e.Title);
        });

        // ProductAttachment configuration
        modelBuilder.Entity<ProductAttachment>(entity =>
        {
            entity.HasOne(e => e.Attachment)
                .WithMany()
                .HasForeignKey(e => e.AttachmentId)
                .OnDelete(DeleteBehavior.Cascade);
            
            entity.HasIndex(e => e.ObjectId);
            entity.HasIndex(e => e.AttachmentId);
        });

        // Attachment configuration
        modelBuilder.Entity<Attachment>(entity =>
        {
            entity.HasIndex(e => e.FileName);
        });
    }
}
