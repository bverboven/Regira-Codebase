# WebShop Sample Project

This is a complete working example of a webshop API built with the Regira Entities framework.

## Prerequisites

- .NET 9.0 SDK
- SQL Server or LocalDB

## Getting Started

1. **Restore packages:**
   ```bash
   dotnet restore
   ```

2. **Update the connection string** in `appsettings.json` if needed.

3. **Run the application:**
   ```bash
   dotnet run
   ```

4. **Open Swagger UI:**
   Navigate to `https://localhost:5001/swagger` to explore the API.

## Features Demonstrated

- ? Entity Models with built-in interfaces (IHasTimestamps, IArchivable, IHasTitle, etc.)
- ? Search Objects with custom filtering properties
- ? Custom Enums for sorting and includes
- ? Query Builders (Filtered, Sorted, Includes)
- ? DTOs for input and output
- ? Controllers with automatic CRUD endpoints
- ? Database Context with proper configuration
- ? Normalization (automatic and custom)
- ? Attachments with file storage
- ? Dependency Injection configuration
- ? AfterMappers for custom DTO mapping

## Database Setup

The application uses Entity Framework Core with code-first approach. The database will be created automatically on first run with seed data.

### Manual Migration (Optional)

```bash
dotnet ef migrations add InitialCreate
dotnet ef database update
```

## API Endpoints

### Products
- `GET /api/products` - List all products
- `GET /api/products/{id}` - Get product details
- `POST /api/products` - Create a new product
- `PUT /api/products/{id}` - Update a product
- `DELETE /api/products/{id}` - Delete a product (soft delete)
- `GET /api/products/low-stock` - Get low stock products

### Categories
- `GET /api/categories` - List all categories
- `GET /api/categories/{id}` - Get category details
- `POST /api/categories` - Create a new category
- `PUT /api/categories/{id}` - Update a category
- `DELETE /api/categories/{id}` - Delete a category

### Product Attachments
- `GET /api/products/{productId}/attachments` - List product attachments
- `POST /api/products/{productId}/attachments` - Upload attachment
- `DELETE /api/products/{productId}/attachments/{id}` - Delete attachment

## Sample Requests

### Create a Product

```http
POST /api/products
Content-Type: application/json

{
  "title": "Gaming Laptop",
  "description": "High-end gaming laptop with RTX 4080",
  "price": 2499.99,
  "stock": 15,
  "categoryId": 2
}
```

### Search Products

```http
GET /api/products?q=laptop&categoryId=2&minPrice=1000&maxPrice=3000&inStock=true
```

## Project Structure

```
WebShop/
??? Models/
?   ??? Entities/       # Domain entities
?   ??? DTOs/          # Data Transfer Objects
?   ??? SearchObjects/ # Search/filter models
?   ??? Enums/         # Enumerations
??? Data/              # DbContext and seeding
??? Services/
?   ??? QueryBuilders/ # Custom query logic
?   ??? Normalizers/   # Text normalization
??? Controllers/       # API endpoints
```

## Learn More

For detailed documentation, see the main [Regira Entities Documentation](../../docs/Entities/).
