using Regira.Normalizing.Abstractions;
using Regira.Entities.Normalizing;
using WebShop.Models.Entities;

namespace WebShop.Services.Normalizers;

public class ProductNormalizer : EntityNormalizerBase<Product>
{
    private readonly INormalizer _normalizer;

    public ProductNormalizer(INormalizer normalizer)
    {
        _normalizer = normalizer;
    }

    public override async Task HandleNormalize(Product item)
    {
        // Combine title and description
        var content = $"{item.Title} {item.Description}".Trim();
        item.NormalizedContent = await _normalizer.Normalize(content);
    }
}
