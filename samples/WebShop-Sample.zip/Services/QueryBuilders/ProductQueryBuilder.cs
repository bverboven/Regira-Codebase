using Regira.Entities.Services.QueryBuilders;
using WebShop.Models.Entities;
using WebShop.Models.SearchObjects;

namespace WebShop.Services.QueryBuilders;

public class ProductQueryBuilder : FilteredQueryBuilderBase<Product, int, ProductSearchObject>
{
    public override IQueryable<Product> Build(IQueryable<Product> query, ProductSearchObject? so)
    {
        if (so == null) return query;

        // Category filtering
        if (so.CategoryId.HasValue)
        {
            query = query.Where(x => x.CategoryId == so.CategoryId.Value);
        }

        if (so.CategoryIds?.Any() == true)
        {
            query = query.Where(x => so.CategoryIds.Contains(x.CategoryId));
        }

        // Price filtering
        if (so.MinPrice.HasValue)
        {
            query = query.Where(x => x.Price >= so.MinPrice.Value);
        }

        if (so.MaxPrice.HasValue)
        {
            query = query.Where(x => x.Price <= so.MaxPrice.Value);
        }

        // Stock filtering
        if (so.MinStock.HasValue)
        {
            query = query.Where(x => x.Stock >= so.MinStock.Value);
        }

        if (so.InStock == true)
        {
            query = query.Where(x => x.Stock > 0);
        }
        else if (so.InStock == false)
        {
            query = query.Where(x => x.Stock == 0);
        }

        return query;
    }
}
