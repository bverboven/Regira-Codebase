using Microsoft.EntityFrameworkCore;
using Regira.Entities.Services.QueryBuilders;
using WebShop.Models.Entities;
using WebShop.Models.Enums;

namespace WebShop.Services.QueryBuilders;

public class ProductIncludesQueryBuilder : IncludesQueryBuilderBase<Product, ProductIncludes>
{
    public override IQueryable<Product> Build(IQueryable<Product> query, ProductIncludes? includes)
    {
        if (includes == null) return query;

        if (includes.Value.HasFlag(ProductIncludes.Category))
        {
            query = query.Include(x => x.Category);
        }

        if (includes.Value.HasFlag(ProductIncludes.Attachments))
        {
            query = query.Include(x => x.Attachments);
        }

        return query;
    }
}
