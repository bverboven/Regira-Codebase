using Regira.Entities.Services.QueryBuilders;
using WebShop.Models.Entities;
using WebShop.Models.Enums;

namespace WebShop.Services.QueryBuilders;

public class ProductSortedQueryBuilder : SortedQueryBuilderBase<Product, ProductSortBy>
{
    public override IQueryable<Product> Build(IQueryable<Product> query, IList<ProductSortBy> sortBy)
    {
        foreach (var sort in sortBy)
        {
            query = sort switch
            {
                ProductSortBy.Title => query.OrderBy(x => x.Title),
                ProductSortBy.TitleDesc => query.OrderByDescending(x => x.Title),
                ProductSortBy.Price => query.OrderBy(x => x.Price),
                ProductSortBy.PriceDesc => query.OrderByDescending(x => x.Price),
                ProductSortBy.Stock => query.OrderBy(x => x.Stock),
                ProductSortBy.StockDesc => query.OrderByDescending(x => x.Stock),
                ProductSortBy.Created => query.OrderBy(x => x.Created),
                ProductSortBy.CreatedDesc => query.OrderByDescending(x => x.Created),
                ProductSortBy.Category => query.OrderBy(x => x.Category!.Title),
                _ => query.OrderBy(x => x.Id)
            };
        }
        
        return query;
    }
}
